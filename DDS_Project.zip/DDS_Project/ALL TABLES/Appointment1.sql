CREATE TABLE Appointment1 (
   Aid NUMBER PRIMARY KEY,
   Date_ VARCHAR2(100),
   Atype VARCHAR2(100),
   Did NUMBER,
   Pid INT,
   FOREIGN KEY(Did) REFERENCES Doctor2(Did),
   FOREIGN KEY(Pid) REFERENCES p1_p2(Pid)
);


INSERT INTO Appointment1 (Aid, Date_, Atype, Did, Pid) VALUES(1, '2023-03-01', 'checkup', 1, 2);
INSERT INTO Appointment1 (Aid, Date_, Atype, Did, Pid) VALUES(2, '2023-03-05', 'checkup', 2, 5);
INSERT INTO Appointment1 (Aid, Date_, Atype, Did, Pid) VALUES(3, '2023-03-08', 'checkup', 3, 8);
INSERT INTO Appointment1 (Aid, Date_, Atype, Did, Pid) VALUES(4, '2023-03-12', 'checkup', 4, 101);
INSERT INTO Appointment1 (Aid, Date_, Atype, Did, Pid) VALUES(5, '2023-03-15', 'checkup', 5, 105);

commit;

