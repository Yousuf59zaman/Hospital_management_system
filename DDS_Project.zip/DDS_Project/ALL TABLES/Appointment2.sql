CREATE TABLE Appointment2 (
   Aid NUMBER PRIMARY KEY,
   Date_ VARCHAR2(100),
   Atype VARCHAR2(100),
   Did NUMBER,
   Pid INT,
   FOREIGN KEY(Did) REFERENCES Doctor3(Did),
   FOREIGN KEY(Pid) REFERENCES p1_p2(Pid)
);

INSERT INTO Appointment2 (Aid, Date_, Atype, Did, Pid) VALUES(101, '2023-03-01', 'surgery', 101,3);
INSERT INTO Appointment2 (Aid, Date_, Atype, Did, Pid) VALUES(102, '2023-03-05', 'surgery', 103, 6);
INSERT INTO Appointment2 (Aid, Date_, Atype, Did, Pid) VALUES(103, '2023-03-08', 'surgery', 105, 9);
INSERT INTO Appointment2 (Aid, Date_, Atype, Did, Pid) VALUES(104, '2023-03-12', 'room_book', 102, 102);
INSERT INTO Appointment2 (Aid, Date_, Atype, Did, Pid) VALUES(105, '2023-03-15', 'room_book', 106, 106);

commit;