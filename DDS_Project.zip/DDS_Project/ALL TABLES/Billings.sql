CREATE TABLE Billings (
    Bid NUMBER PRIMARY KEY,
    charge NUMBER,
    discount NUMBER,
    Aid NUMBER,
    FOREIGN KEY (Aid) REFERENCES Appointment(Aid)
);

INSERT INTO Billings (Bid, charge, discount, Aid) VALUES (1, 100, 10, 101);
INSERT INTO Billings (Bid, charge, discount, Aid) VALUES (2, 200, 20, 105);
INSERT INTO Billings (Bid, charge, discount, Aid) VALUES (3, 300, 30, 3);


commit;
