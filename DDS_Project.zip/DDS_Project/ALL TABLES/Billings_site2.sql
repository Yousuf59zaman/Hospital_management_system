CREATE TABLE Billings (
    Bid NUMBER PRIMARY KEY,
    charge NUMBER,
    discount NUMBER,
    Aid NUMBER,
    FOREIGN KEY(Aid) REFERENCES Appointment2(Aid)
);

INSERT INTO Billings (Bid, charge, discount, Aid) VALUES (4,100,10,4);
INSERT INTO Billings (Bid, charge, discount, Aid) VALUES (5,200,20,5);

commit;



