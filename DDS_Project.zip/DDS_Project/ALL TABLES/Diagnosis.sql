SET PAGESIZE 5000
SET LINESIZE 1000
SET COLSEP " "

COLUMN diagnosis_id FORMAT 9999
COLUMN prescription FORMAT A17
COLUMN exam_report FORMAT A17
COLUMN Aid FORMAT 9999

CREATE TABLE Diagnosis AS
SELECT * FROM Diagnosis1
UNION
SELECT * FROM Diagnosis2;

ALTER TABLE Diagnosis ADD PRIMARY KEY (diagnosis_id);
select * from Diagnosis;

COMMIT;
