CREATE TABLE Diagnosis1 (
    diagnosis_id NUMBER PRIMARY KEY,
    prescription VARCHAR2(255),
    exam_report VARCHAR2(255),
    Aid NUMBER,
    FOREIGN KEY(Aid) REFERENCES Appointment1(Aid)
);


INSERT INTO Diagnosis1 (diagnosis_id, prescription, exam_report, Aid) VALUES (1, 'Paracetamol', 'Sick', 1);
INSERT INTO Diagnosis1 (diagnosis_id, prescription, exam_report, Aid) VALUES (2, 'Aspirin', 'Sick', 2);
INSERT INTO Diagnosis1 (diagnosis_id, prescription, exam_report, Aid) VALUES (3, 'Ibuprofen', 'Normal', 3);

commit;
