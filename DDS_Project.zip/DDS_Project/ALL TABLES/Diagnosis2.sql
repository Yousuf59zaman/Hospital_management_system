CREATE TABLE Diagnosis2 (
    diagnosis_id NUMBER PRIMARY KEY,
    prescription VARCHAR2(255),
    exam_report VARCHAR2(255),
    Aid NUMBER,
    FOREIGN KEY(Aid) REFERENCES Appointment2(Aid)
);


INSERT INTO Diagnosis2 (diagnosis_id, prescription, exam_report, Aid) VALUES (101, 'Paracetamol', 'Normal', 1);
INSERT INTO Diagnosis2 (diagnosis_id, prescription, exam_report, Aid) VALUES (102, 'Aspirin', 'Sick', 2);
INSERT INTO Diagnosis2 (diagnosis_id, prescription, exam_report, Aid) VALUES (103, 'Ibuprofen', 'Sick', 4);

commit;