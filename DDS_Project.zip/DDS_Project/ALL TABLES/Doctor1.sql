DEFINE _COLUMN_WIDTH=15

CREATE TABLE Doctor1(
   Did INT PRIMARY KEY,
   name VARCHAR2(255),
   phone VARCHAR2(255),
   email VARCHAR2(255),
   address VARCHAR2(255)
);

INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (1, 'John Doe', '555-1234', 'johndoe@example.com', '123 Main St');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (2, 'Jane Smith', '555-5678', 'janesmith@example.com', '456 Oak Ave');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (3, 'Michael Lee', '555-9012', 'michaellee@example.com', '789 Maple St');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (4, 'Susan Chen', '555-3456', 'susanchen@example.com', '321 Elm St');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (5, 'David Kim', '555-7890', 'davidkim@example.com', '654 Pine Ave');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (6, 'Jennifer Nguyen', '555-2345', 'jennifernguyen@example.com', '987 Cedar Ln');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (7, 'William Jones', '555-6789', 'williamjones@example.com', '555 Birch Rd');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (8, 'Elizabeth Brown', '555-0123', 'elizabethbrown@example.com', '222 Chestnut St');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (9, 'Andrew Park', '555-4567', 'andrewpark@example.com', '888 Ash St');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (10, 'Emily Davis', '555-8901', 'emilydavis@example.com', '444 Spruce Ave');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (101, 'Brian Wilson', '555-2345', 'brianwilson@example.com', '111 Oak Ln');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (102, 'Amy Thompson', '555-6789', 'amythompson@example.com', '222 Maple Rd');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (103, 'Richard Martin', '555-0123', 'richardmartin@example.com', '333 Elm St');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (104, 'Karen Lee', '555-4567', 'karenlee@example.com', '444 Pine Ave');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (105, 'Daniel Garcia', '555-8901', 'danielgarcia@example.com', '555 Cedar Ln');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (106, 'Maria Hernandez', '555-3456', 'mariahernandez@example.com', '666 Birch Rd');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (107, 'Robert Johnson', '555-7890', 'robertjohnson@example.com', '777 Chestnut St');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (108, 'Melanie Brown', '555-1234', 'melaniebrown@example.com', '888 Ash St');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (109, 'Jessica Kim', '555-5678', 'jessicakim@example.com', '999 Spruce Ave');
INSERT INTO Doctor1 (Did, name, phone, email, address) VALUES (110, 'Steven Chen', '555-9012', 'stevenchen@example.com', '1010 Oak Ave');
 
commit;