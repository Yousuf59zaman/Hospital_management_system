CREATE TABLE Doctor2 (
   Did INT PRIMARY KEY,
   speciality VARCHAR2(255),
   hospital VARCHAR2(255),
   education VARCHAR2(255),
   availability VARCHAR2(255)
);


INSERT INTO Doctor2 (Did, speciality, hospital, education, availability) VALUES (1, 'Pediatrics', 'St. Mary Hospital', 'MD, University of California, San Francisco', 'Monday-Friday, 9am-5pm');
INSERT INTO Doctor2 (Did, speciality, hospital, education, availability) VALUES (2, 'Cardiology', 'Memorial Hospital', 'MD, Stanford University School of Medicine', 'Monday-Friday, 8am-6pm');
INSERT INTO Doctor2 (Did, speciality, hospital, education, availability) VALUES (3, 'Dermatology', 'City Hospital', 'MD, Columbia University College of Physicians and Surgeons', 'Tuesday-Saturday, 10am-7pm');
INSERT INTO Doctor2 (Did, speciality, hospital, education, availability) VALUES (4, 'Oncology', 'University Hospital', 'MD, Yale School of Medicine', 'Monday-Friday, 9am-5pm');
INSERT INTO Doctor2 (Did, speciality, hospital, education, availability) VALUES (5, 'Endocrinology', 'Community Hospital', 'MD, Harvard Medical School', 'Monday-Wednesday, 8am-12pm');
INSERT INTO Doctor2 (Did, speciality, hospital, education, availability) VALUES (6, 'Neurology', 'Methodist Hospital', 'MD, Johns Hopkins University School of Medicine', 'Thursday-Friday, 10am-4pm');
INSERT INTO Doctor2 (Did, speciality, hospital, education, availability) VALUES (7, 'Gastroenterology', 'St. Vincent Hospital', 'MD, University of Pennsylvania School of Medicine', 'Monday-Friday, 8am-5pm');
INSERT INTO Doctor2 (Did, speciality, hospital, education, availability) VALUES (8, 'Allergy and Immunology', 'Mercy Hospital', 'MD, Duke University School of Medicine', 'Monday-Wednesday, 9am-12pm');
INSERT INTO Doctor2 (Did, speciality, hospital, education, availability) VALUES (9, 'Rheumatology', 'Mount Sinai Hospital', 'MD, Washington University School of Medicine', 'Thursday-Friday, 9am-4pm');
INSERT INTO Doctor2 (Did, speciality, hospital, education, availability) VALUES (10, 'Psychiatry', 'UCLA Medical Center', 'MD, University of Michigan Medical School', 'Tuesday-Thursday, 11am-5pm');


commit;