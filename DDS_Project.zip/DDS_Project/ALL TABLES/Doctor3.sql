CREATE TABLE Doctor3 (
   Did INT PRIMARY KEY,
   speciality VARCHAR2(255),
   hospital VARCHAR2(255),
   education VARCHAR2(255),
   availability VARCHAR2(255)
);



INSERT INTO Doctor3 (Did, speciality, hospital, education, availability) VALUES (101, 'Surgery', 'Mount Sinai Hospital', 'MD, Columbia University College of Physicians and Surgeons', 'Monday-Friday, 8am-5pm');
INSERT INTO Doctor3 (Did, speciality, hospital, education, availability) VALUES (102, 'Medicine', 'NewYork-Presbyterian Hospital', 'MD, Harvard Medical School', 'Monday-Friday, 9am-6pm');
INSERT INTO Doctor3 (Did, speciality, hospital, education, availability) VALUES (103, 'Surgery', 'Cedars-Sinai Medical Center', 'MD, Johns Hopkins University School of Medicine', 'Tuesday-Saturday, 10am-7pm');
INSERT INTO Doctor3 (Did, speciality, hospital, education, availability) VALUES (104, 'Medicine', 'Massachusetts General Hospital', 'MD, Yale School of Medicine', 'Monday-Friday, 8am-4pm');
INSERT INTO Doctor3 (Did, speciality, hospital, education, availability) VALUES (105, 'Surgery', 'Stanford Hospital', 'MD, Duke University School of Medicine', 'Monday-Wednesday, 9am-12pm');
INSERT INTO Doctor3 (Did, speciality, hospital, education, availability) VALUES (106, 'Medicine', 'Brigham and Women''s Hospital', 'MD, Washington University School of Medicine', 'Thursday-Friday, 9am-4pm');
INSERT INTO Doctor3 (Did, speciality, hospital, education, availability) VALUES (107, 'Surgery', 'Mayo Clinic', 'MD, University of Pennsylvania School of Medicine', 'Monday-Friday, 8am-5pm');
INSERT INTO Doctor3 (Did, speciality, hospital, education, availability) VALUES (108, 'Medicine', 'Johns Hopkins Hospital', 'MD, Stanford University School of Medicine', 'Monday-Wednesday, 10am-2pm');
INSERT INTO Doctor3 (Did, speciality, hospital, education, availability) VALUES (109, 'Surgery', 'University of California, San Francisco Medical Center', 'MD, University of California, San Francisco', 'Thursday-Friday, 8am-3pm');
INSERT INTO Doctor3 (Did, speciality, hospital, education, availability) VALUES (110, 'Medicine', 'University of Michigan Health System', 'MD, Columbia University College of Physicians and Surgeons', 'Tuesday-Thursday, 11am-5pm');



commit;