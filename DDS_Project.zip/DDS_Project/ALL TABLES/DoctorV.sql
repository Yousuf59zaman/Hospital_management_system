SET PAGESIZE 5000
SET LINESIZE 1000
SET COLSEP " "

COLUMN Did FORMAT 99999
COLUMN speciality FORMAT A17
COLUMN hospital FORMAT A17
COLUMN education FORMAT A17
COLUMN availability FORMAT A17

CREATE TABLE DoctorV AS
SELECT Doctor1.Did, Doctor1.name, Doctor1.phone, Doctor1.email, Doctor1.address,
       DoctorH.speciality, DoctorH.hospital, DoctorH.education, DoctorH.availability
FROM Doctor1
INNER JOIN DoctorH
ON Doctor1.Did = DoctorH.Did;


ALTER TABLE DoctorV ADD PRIMARY KEY (Did);
select * from DoctorV;
COMMIT;
