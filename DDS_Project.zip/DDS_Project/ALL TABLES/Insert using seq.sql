CREATE SEQUENCE users
START WITH 1
INCREMENT BY 1
NOMINVALUE
NOMAXVALUE
NOCYCLE;

INSERT INTO UserInfo(ID, Name, Age, Gender, Phone, Email, Address, DOB)
VALUES(users.NEXTVAL, 'Karim', 35, 'Male', '1234567890', 'johndoe@email.com', '1 Main St', '1986-01-01');
  