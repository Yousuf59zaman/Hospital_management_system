CREATE TABLE Patient1 (
    Pid INT PRIMARY KEY,
    name VARCHAR2(100),
    phone VARCHAR2(100),
    email VARCHAR2(100),
    address VARCHAR2(100),
    age NUMBER,
    gender VARCHAR2(100),
    medical_history VARCHAR2(255),
    c_state VARCHAR2(255)
);

INSERT INTO Patient1 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES 
(1, 'John Smith', '555-1234', 'jsmith@email.com', '123 Main St, Anytown USA', 45, 'Male', 'None', 'normal');
INSERT INTO Patient1 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES 
(2, 'Jane Doe', '555-5678', 'jdoe@email.com', '456 Oak Ave, Anytown USA', 32, 'Female', 'Asthma', 'normal');
INSERT INTO Patient1 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES 
(3, 'Bob Johnson', '555-9012', 'bjohnson@email.com', '789 Elm St, Anytown USA', 60, 'Male', 'High blood pressure', 'normal');
INSERT INTO Patient1 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES 
(4, 'Sara Lee', '555-3456', 'slee@email.com', '321 Pine St, Anytown USA', 28, 'Female', 'None', 'normal');
INSERT INTO Patient1 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES 
(5, 'Tom Jackson', '555-7890', 'tjackson@email.com', '654 Cedar Ave, Anytown USA', 42, 'Male', 'Diabetes', 'normal');
INSERT INTO Patient1 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES 
(6, 'Mary Brown', '555-2345', 'mbrown@email.com', '987 Birch Rd, Anytown USA', 55, 'Female', 'Arthritis', 'normal');
INSERT INTO Patient1 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES 
(7, 'David Kim', '555-6789', 'dkim@email.com', '246 Maple Dr, Anytown USA', 36, 'Male', 'None', 'normal');
INSERT INTO Patient1 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES 
(8, 'Karen Nguyen', '555-0123', 'knguyen@email.com', '369 Spruce St, Anytown USA', 47, 'Female', 'Allergies', 'normal');
INSERT INTO Patient1 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES 
(9, 'Adam Wilson', '555-4567', 'awilson@email.com', '802 Pine Ave, Anytown USA', 29, 'Male', 'None', 'normal');
INSERT INTO Patient1 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES 
(10, 'Grace Lee', '555-8901', 'glee@email.com', '135 Oak St, Anytown USA', 51, 'Female', 'High cholesterol', 'normal');



commit;