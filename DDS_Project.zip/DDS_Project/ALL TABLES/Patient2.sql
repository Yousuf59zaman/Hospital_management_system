CREATE TABLE Patient2(
    Pid INT PRIMARY KEY,
    name VARCHAR2(100),
    phone VARCHAR2(100),
    email VARCHAR2(100),
    address VARCHAR2(100),
    age NUMBER,
    gender VARCHAR2(100),
    medical_history VARCHAR2(255),
    c_state VARCHAR2(255)
);
    
 
INSERT INTO Patient2 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES(101, 'George Smith', '555-1234', 'gsmith@email.com', '123 Main St, Anytown USA', 47, 'Male', 'None', 'abnormal');
INSERT INTO Patient2 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES(102, 'Samantha Brown', '555-5678', 'sbrown@email.com', '456 Oak Ave, Anytown USA', 25, 'Female', 'Migraines', 'abnormal');
INSERT INTO Patient2 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES(103, 'Mark Johnson', '555-9012', 'mjohnson@email.com', '789 Elm St, Anytown USA', 53, 'Male', 'High blood pressure', 'abnormal');
INSERT INTO Patient2 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES(104, 'Anna Lee', '555-3456', 'alee@email.com', '321 Pine St, Anytown USA', 36, 'Female', 'Anemia', 'abnormal');
INSERT INTO Patient2 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES(105, 'Eric Jackson', '555-7890', 'ejackson@email.com', '654 Cedar Ave, Anytown USA', 31, 'Male', 'Asthma', 'abnormal');
INSERT INTO Patient2 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES(106, 'Lisa Kim', '555-6789', 'lkim@email.com', '246 Maple Dr, Anytown USA', 29, 'Female', 'Depression', 'abnormal');
INSERT INTO Patient2 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES(107, 'Paul Nguyen', '555-0123', 'pnguyen@email.com', '369 Spruce St, Anytown USA', 49, 'Male', 'High blood pressure', 'abnormal');
INSERT INTO Patient2 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES(108, 'Rachel Wilson', '555-4567', 'rwilson@email.com', '802 Pine Ave, Anytown USA', 62, 'Female', 'Osteoporosis', 'abnormal');
INSERT INTO Patient2 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES(109, 'Michael Brown', '555-2345', 'mbrown@email.com', '987 Birch Rd, Anytown USA', 57, 'Male', 'High cholesterol', 'abnormal');
INSERT INTO Patient2 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES(110, 'Sophie Lee', '555-8901', 'slee@email.com', '135 Oak St, Anytown USA', 41, 'Female', 'None', 'abnormal');


commit;