CREATE TABLE Payment (
    Pay_id INT PRIMARY KEY,
    Aid NUMBER,
    pay_status VARCHAR2(10),
    FOREIGN KEY (Aid) REFERENCES Appointment(Aid)
);

INSERT INTO Payment (Pay_id,Aid,pay_status)
VALUES (1,101,'paid');
INSERT INTO Payment (Pay_id,Aid,pay_status)
VALUES (2,3,'paid');
INSERT INTO Payment (Pay_id,Aid,pay_status)
VALUES (3,5,'paid');

commit;
