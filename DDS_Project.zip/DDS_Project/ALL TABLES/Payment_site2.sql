CREATE TABLE Payment (
    Aid NUMBER,
    Pay_id NUMBER,
    pay_status VARCHAR2(100),
    FOREIGN KEY(Aid) REFERENCES Appointment2(Aid)
);

INSERT INTO Payment (Pay_id, Aid, pay_status)
VALUES (4, 4, 'paid');
INSERT INTO Payment (Aid, Pid, pay_status)
VALUES (5, 5, 'unpaid');

commit;
