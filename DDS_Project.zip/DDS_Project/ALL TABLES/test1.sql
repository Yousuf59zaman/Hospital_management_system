SET SERVEROUTPUT ON;
SET VERIFY OFF;
declare
   vDid INT:=0;
   insert_delete NUMBER:=&x;
   name VARCHAR2(100):='&name';
   phone VARCHAR2(100):='&phone';
   email VARCHAR2(100):='&email';
   address VARCHAR2(100):='&address';
   speciality VARCHAR2(100):='&speciality';
   hospital VARCHAR2(100):='&hospital';
   education VARCHAR2(100):='&education';
   availability VARCHAR2(100):='&availability';
BEGIN
   IF insert_delete=1 THEN
      if(speciality= 'surgery' or speciality='none') THEN
	        DBMS_OUTPUT.PUT_LINE('dassasd');
            select max(Did) into vDid from doctor2@site_link;
	        vDid:=vDid+1;
            INSERT INTO Doctor1(Did, name, phone, email, address, speciality, hospital, education, availability) VALUES(vDid, name, phone, email, address, speciality, hospital, education, availability);
			
      ELSE
           select max(Did) into vDid from doctor1; 
           vDid:=vDid+1;
           INSERT INTO Doctor1(Did, name, phone, email, address, speciality, hospital, education, availability) VALUES(vDid, name, phone, email, address, speciality, hospital, education, availability);
      end if;
   ELSE
      DBMS_OUTPUT.PUT_LINE('2');   
   end if;
end;
/

