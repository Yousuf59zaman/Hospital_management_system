SET SERVEROUTPUT ON;
SET VERIFY OFF;

-------DECLARING A PACKAGE----------
CREATE OR REPLACE PACKAGE mypack AS
	
	PROCEDURE P1;
END mypack;
/


--------IMPLEMENTING THE BODY OF A PACKAGE-------- 
CREATE OR REPLACE PACKAGE BODY mypack AS
	
	PROCEDURE P1
	IS
	
	BEGIN
			DBMS_OUTPUT.PUT_LINE('Enter 1(Insert), 2(Update), 3(delete), 4(Show) for Doctor');
		
	END P1;
	

	
END mypack;
/


------------call functions/procedures in package-------
--SELECT mypack.F1(20) FROM DUAL;
--EXEC mypack.P1(21);
ACCEPT x NUMBER PROMPT "Enter Aid: "
DECLARE
	A int:=&x;
BEGIN
	
    
	
	
END;
/



