SET SERVEROUTPUT ON;
SET VERIFY OFF;

-------DECLARING A PACKAGE----------
CREATE OR REPLACE PACKAGE mypack AS
	
	PROCEDURE P1;
END mypack;
/

--------IMPLEMENTING THE BODY OF A PACKAGE-------- 
CREATE OR REPLACE PACKAGE BODY mypack AS
	
	PROCEDURE P1
	IS
	BEGIN
                DBMS_OUTPUT.PUT_LINE('Enter to Modify: 1(Doctor), 2(Patient), 3(Appointment), 4(Diagnosis), 5(Billings), 6(Payment)');		
	END P1;
	

	
END mypack;
/

ACCEPT x NUMBER PROMPT "Enter Aid: "
DECLARE
	A int:=&x;
        B NUMBER;
        userDefException EXCEPTION;
BEGIN
	
      IF A=1 THEN
         mypack.P1;
      ELSE
         RAISE userDefException;
      END IF;
EXCEPTION
	WHEN userDefException THEN
		DBMS_OUTPUT.PUT_LINE('Enter Correct Id!!');
	
	WHEN TOO_MANY_ROWS THEN
		DBMS_OUTPUT.PUT_LINE('MANY ROWS DETECTED');
		
	WHEN NO_DATA_FOUND THEN
		DBMS_OUTPUT.PUT_LINE('DATA NOT FOUND');
	
	WHEN ZERO_DIVIDE THEN
		DBMS_OUTPUT.PUT_LINE('CANNOT DIVIDE BY ZERO');
	
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('OTHER ERRORS FOUND');
END;
/




