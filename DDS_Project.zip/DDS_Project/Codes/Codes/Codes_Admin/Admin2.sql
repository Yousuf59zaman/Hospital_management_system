SET SERVEROUTPUT ON;
SET VERIFY OFF;

-------DECLARING A PACKAGE----------
CREATE OR REPLACE PACKAGE mypack AS
	
	PROCEDURE P1(A IN NUMBER);
END mypack;
/

--------IMPLEMENTING THE BODY OF A PACKAGE-------- 
CREATE OR REPLACE PACKAGE BODY mypack AS
	
	PROCEDURE P1(A IN NUMBER)
	IS
	BEGIN  
           IF A=1 THEN 
                 DBMS_OUTPUT.PUT_LINE('Enter 1(Insert), 2(Update), 3(Delete), 4(Show) For Doctor Table' );		
	   ELSIF A=2 THEN
                 DBMS_OUTPUT.PUT_LINE('Enter 1(Insert), 2(Update), 3(Delete), 4(Show) For Patient Table' );		
           ELSIF A=3 THEN
                 DBMS_OUTPUT.PUT_LINE('Enter 1(Insert), 2(Update), 3(Delete), 4(Show) For AppointmentTable' );		
	   ELSIF A=4 THEN
                 DBMS_OUTPUT.PUT_LINE('Enter 1(Insert), 2(Update), 3(Delete), 4(Show) For Diagnosis Table' );	
           ELSIF A=5 THEN
                 DBMS_OUTPUT.PUT_LINE('Enter 1(Insert), 2(Update), 3(Delete), 4(Show) For Billings Table' );	
           ELSIF A=6 THEN
                 DBMS_OUTPUT.PUT_LINE('Enter 1(Insert), 2(Update), 3(Delete), 4(Show) For Payment Table' );	
           END IF;
        END P1;
	

	
END mypack;
/

ACCEPT x NUMBER PROMPT "Enter: "
DECLARE
	A NUMBER:=&x;
        userDefException EXCEPTION;
BEGIN
      IF A>=1 AND A<=6 THEN 
         mypack.P1(A);
      ELSE
         RAISE userDefException;
      END IF;
EXCEPTION
	WHEN userDefException THEN
		DBMS_OUTPUT.PUT_LINE('Enter Value 1 to 6!!');
	
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('OTHER ERRORS FOUND');
END;
/




