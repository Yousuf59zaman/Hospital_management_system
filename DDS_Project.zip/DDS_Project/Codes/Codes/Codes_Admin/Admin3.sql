SET SERVEROUTPUT ON;
SET VERIFY OFF;


-------DECLARING A PACKAGE----------
CREATE OR REPLACE PACKAGE mypack AS
	
	PROCEDURE P1(A IN NUMBER);
END mypack;
/

--------IMPLEMENTING THE BODY OF A PACKAGE-------- 
CREATE OR REPLACE PACKAGE BODY mypack AS
	
	PROCEDURE P1(A IN NUMBER)
	IS
	BEGIN  
            IF A=1 THEN 
                 DBMS_OUTPUT.PUT_LINE('Insert:' );		
	        ELSIF A=2 THEN
                 DBMS_OUTPUT.PUT_LINE('Update:' );		
            ELSIF A=3 THEN
                 DBMS_OUTPUT.PUT_LINE('Delete:' );		
	        ELSIF A=4 THEN
                 DBMS_OUTPUT.PUT_LINE('Show:' );	
            END IF;
    END P1;
	

	
END mypack;
/


ACCEPT x NUMBER PROMPT "Enter: "
DECLARE
	A NUMBER:=&x;
        userDefException EXCEPTION;
BEGIN
      IF A>=1 AND A<=4 THEN 
         mypack.P1(A);
      ELSE
         RAISE userDefException;
      END IF;
EXCEPTION
	WHEN userDefException THEN
		DBMS_OUTPUT.PUT_LINE('Enter Value 1 to 6!!');
	
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('OTHER ERRORS FOUND');
END;
/