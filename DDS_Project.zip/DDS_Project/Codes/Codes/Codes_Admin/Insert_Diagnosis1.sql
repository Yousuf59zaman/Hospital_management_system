DECLARE
	vAid NUMBER:=&Aid;
        vAtype Appointment1.Atype%TYPE;
BEGIN
      select Atype into vAtype from Appointment1 where Aid=vAid;
      DBMS_OUTPUT.PUT_LINE('Aid Found');
EXCEPTION
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('OTHER ERRORS FOUND');
END;
/






DECLARE
 
	prescription VARCHAR2(255) :='&prescription';
	exam_report VARCHAR2(255) :='&exam_report';
        Aid NUMBER := &Aid;
        userDefException EXCEPTION;
	vdiagnosis_id Diagnosis1.diagnosis_id%TYPE;
BEGIN
     select max(diagnosis_id) into vdiagnosis_id from Diagnosis1;
     vdiagnosis_id:=vdiagnosis_id+1;
     INSERT INTO Diagnosis1 (diagnosis_id, prescription, exam_report, Aid) VALUES 
     (vdiagnosis_id, prescription, exam_report, Aid); 
 
EXCEPTION
	
	WHEN TOO_MANY_ROWS THEN
		DBMS_OUTPUT.PUT_LINE('MANY ROWS DETECTED');
		
	WHEN NO_DATA_FOUND THEN
		DBMS_OUTPUT.PUT_LINE('DATA NOT FOUND');
	
	WHEN ZERO_DIVIDE THEN
		DBMS_OUTPUT.PUT_LINE('CANNOT DIVIDE BY ZERO');
	
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('OTHER ERRORS FOUND');
END;
/