SET SERVEROUTPUT ON;
SET VERIFY OFF;

DECLARE
	name VARCHAR2(255) :='&name';
	phone VARCHAR2(255) :='&phone';
	email VARCHAR2(255) :='&email';
	address VARCHAR2(255) :='&address';
	speciality VARCHAR2(255) :='&speciality';
	hospital VARCHAR2(255) :='&hospital';
	education VARCHAR2(255) :='&education';
	availability VARCHAR2(255) :='&availability';
    userDefException EXCEPTION;
	vDid DoctorV1.Did%TYPE;
BEGIN
     
  IF speciality != 'Surgery' THEN
     select max(Did) into vDid from DoctorV1;
	 vDid:=vDid+1;
     INSERT INTO DoctorV1 (Did, name, phone, email, address, speciality, hospital ,education,availability) VALUES 
     (vDid,name, phone, email, address, speciality,  hospital, education, availability); 
  ELSIF speciality='Surgery' or speciality='Medicine' THEN
      select max(Did) into vDid from DoctorV2@site2;
	 vDid:=vDid+1;
     INSERT INTO DoctorV2@site2 (Did, name, phone, email, address, speciality, hospital ,education,availability) VALUES 
     (vDid,name, phone, email, address, speciality,  hospital, education, availability); 
  ELSE  
      RAISE userDefException;
  END IF;
EXCEPTION
        WHEN userDefException THEN
                DBMS_OUTPUT.PUT_LINE('Enter speciality either Sugery or Medicine or Else!!'); 
	WHEN TOO_MANY_ROWS THEN
		DBMS_OUTPUT.PUT_LINE('MANY ROWS DETECTED');
		
	WHEN NO_DATA_FOUND THEN
		DBMS_OUTPUT.PUT_LINE('DATA NOT FOUND');
	
	WHEN ZERO_DIVIDE THEN
		DBMS_OUTPUT.PUT_LINE('CANNOT DIVIDE BY ZERO');
	
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('OTHER ERRORS FOUND');
END;
/