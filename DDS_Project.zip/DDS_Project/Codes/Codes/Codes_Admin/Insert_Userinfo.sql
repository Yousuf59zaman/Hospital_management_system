SET SERVEROUTPUT ON;
SET VERIFY OFF;

DECLARE
	Name VARCHAR2(255) :='&name';
	Age NUMBER :='&age';
	Gender VARCHAR2(255) :='&gender';
	Phone VARCHAR2(255) :='&phone';
	Email VARCHAR2(255) :='&email';
	Address VARCHAR2(255) :='&address';
	DOB VARCHAR2(255) :='&DOB';
        userDefException EXCEPTION;
	vid userinfo.id%TYPE;
BEGIN
     select max(id) into vid from userinfo;
	 vid:=vid+1;
     INSERT INTO userinfo (ID, Name, Age, Gender, Phone, Email, Address, DOB) VALUES 
     (vid, Name, Age, Gender, Phone, Email, Address, DOB); 
 
EXCEPTION
	
	WHEN TOO_MANY_ROWS THEN
		DBMS_OUTPUT.PUT_LINE('MANY ROWS DETECTED');
		
	WHEN NO_DATA_FOUND THEN
		DBMS_OUTPUT.PUT_LINE('DATA NOT FOUND');
	
	WHEN ZERO_DIVIDE THEN
		DBMS_OUTPUT.PUT_LINE('CANNOT DIVIDE BY ZERO');
	
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('OTHER ERRORS FOUND');
END;
/