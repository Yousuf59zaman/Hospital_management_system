SET PAGESIZE 5000
SET LINESIZE 1000
SET COLSEP " "

COLUMN Did FORMAT 99999
COLUMN name FORMAT A17
COLUMN phone FORMAT A17
COLUMN email FORMAT A17
COLUMN address FORMAT A17
COLUMN speciality FORMAT A17
COLUMN hospital FORMAT A17
COLUMN education FORMAT A17
COLUMN availability FORMAT A17

CREATE TABLE DoctorV1 AS
SELECT Doctor1.Did, Doctor1.name, Doctor1.phone, Doctor1.email, Doctor1.address,
       Doctor2.speciality, Doctor2.hospital, Doctor2.education, Doctor2.availability
FROM Doctor1
INNER JOIN Doctor2
ON Doctor1.Did = Doctor2.Did;


ALTER TABLE DoctorV1 ADD PRIMARY KEY (Did);
select * from DoctorV1;
COMMIT;
