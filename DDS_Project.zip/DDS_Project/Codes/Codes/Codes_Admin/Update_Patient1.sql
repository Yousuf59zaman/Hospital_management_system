SET SERVEROUTPUT ON;
SET VERIFY OFF;

DECLARE
	vPid NUMBER :=&Pid;
	
BEGIN
     
     Update Patient1 set  where Pid=vPid;
	
EXCEPTION	
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('Cannot be deleted');
END;
/