SET SERVEROUTPUT ON;
SET VERIFY OFF;

DECLARE
	vid NUMBER :=&id;
	
BEGIN
     
     delete userinfo where id=vid;
	
EXCEPTION	
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('Cannot be deleted');
END;
/