SET SERVEROUTPUT ON;
SET VERIFY OFF;

DECLARE
	name VARCHAR2(255) :='&name';
	phone VARCHAR2(255) :='&phone';
	email VARCHAR2(255) :='&email';
	address VARCHAR2(255) :='&address';
	age NUMBER :=&age;
	gender VARCHAR2(255) :='&gender';
	medical_history VARCHAR2(255) :='&medical_history';
	c_state VARCHAR2(255) :='&c_state';
    userDefException EXCEPTION;
	vPid Patient1.Pid%TYPE;
BEGIN
     
  IF c_state ='normal' THEN
     select max(Pid) into vPid from Patient1;
     vPid:=vPid+1;
     INSERT INTO Patient1 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES 
     (vPid,name, phone, email, address, age, gender, medical_history, c_state);
  ELSIF c_state='abnormal' THEN
      select max(Pid) into vPid from Patient2;
     vPid:=vPid+1;
     INSERT INTO Patient2 (Pid, name, phone, email, address, age, gender, medical_history, c_state) VALUES 
     (vPid,name, phone, email, address, age, gender, medical_history, c_state);
  ELSE  
      RAISE userDefException;
  END IF;
      
 
EXCEPTION
        WHEN  userDefException THEN
                DBMS_OUTPUT.PUT_LINE('Enter c_state either normal or abnormal');
	WHEN TOO_MANY_ROWS THEN
		DBMS_OUTPUT.PUT_LINE('MANY ROWS DETECTED');
		
	WHEN NO_DATA_FOUND THEN
		DBMS_OUTPUT.PUT_LINE('DATA NOT FOUND');
	
	WHEN ZERO_DIVIDE THEN
		DBMS_OUTPUT.PUT_LINE('CANNOT DIVIDE BY ZERO');
	
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('OTHER ERRORS FOUND');
END;
/