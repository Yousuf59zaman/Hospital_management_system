SET SERVEROUTPUT ON;
SET VERIFY OFF;

BEGIN
         DBMS_OUTPUT.PUT_LINE('Services: 1(Appointment), 2(Room_Book/Surgery)');
     
EXCEPTION

	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('OTHER ERRORS FOUND');
END;
/

DECLARE
	A NUMBER := &ServicesNo;
        userDefException EXCEPTION;
        vDid Doctor2.Did%TYPE;
        vspeciality Doctor2.speciality%TYPE;
  
BEGIN
      
      IF A=1 THEN
         DBMS_OUTPUT.PUT_LINE('The Doctors Info for Checkup: ');
         DBMS_OUTPUT.PUT_LINE('Did'|| ' ' || 'speciality');
         FOR R IN (SELECT * FROM Doctor2) LOOP
		vDid := R.Did;
		vspeciality := R.speciality;
		DBMS_OUTPUT.PUT_LINE(vDid|| ' ' || vspeciality);
		
	 END LOOP;
      ELSIF A=2 THEN
         DBMS_OUTPUT.PUT_LINE('The Doctors Info for Surgery/Room Booking: ');
         DBMS_OUTPUT.PUT_LINE('Did'|| ' ' || 'speciality');
         FOR R IN (SELECT * FROM Doctor3) LOOP
		vDid := R.Did;
		vspeciality := R.speciality;
		DBMS_OUTPUT.PUT_LINE(vDid || ' ' || vspeciality);
		
         END LOOP;
      ELSE
         RAISE userDefException;
      END IF;
EXCEPTION
	WHEN userDefException THEN
		DBMS_OUTPUT.PUT_LINE('Enter Either 1 or 2!!');
	
	WHEN TOO_MANY_ROWS THEN
		DBMS_OUTPUT.PUT_LINE('MANY ROWS DETECTED');
		
	WHEN NO_DATA_FOUND THEN
		DBMS_OUTPUT.PUT_LINE('DATA NOT FOUND');
	
	WHEN ZERO_DIVIDE THEN
		DBMS_OUTPUT.PUT_LINE('CANNOT DIVIDE BY ZERO');
	
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('OTHER ERRORS FOUND');
END;
/




