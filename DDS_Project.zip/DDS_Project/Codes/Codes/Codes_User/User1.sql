SET SERVEROUTPUT ON;
SET VERIFY OFF;

-------DECLARING A PACKAGE----------
CREATE OR REPLACE PACKAGE mypack AS
	
	PROCEDURE P1(A IN NUMBER);
END mypack;
/

--------IMPLEMENTING THE BODY OF A PACKAGE-------- 
CREATE OR REPLACE PACKAGE BODY mypack AS
	
	PROCEDURE P1(A IN NUMBER)
	IS
	BEGIN
             IF A=1 THEN
                 DBMS_OUTPUT.PUT_LINE('Enter your user id: ');	
             ELSIF A=2 THEN
                 DBMS_OUTPUT.PUT_LINE('Enter Signup Info: ');	
             END IF;                
	
	END P1;
	

	
END mypack;
/

ACCEPT x NUMBER PROMPT "Enter 1(Login), 2(Register): "
DECLARE
	A int:=&x;
        userDefException EXCEPTION;
BEGIN
	
      IF A=1 or A=2 THEN
         mypack.P1(A);
      ELSE
         RAISE userDefException;
      END IF;
EXCEPTION
	WHEN userDefException THEN
		DBMS_OUTPUT.PUT_LINE('Enter Either 1 or 2!!');
	
	WHEN TOO_MANY_ROWS THEN
		DBMS_OUTPUT.PUT_LINE('MANY ROWS DETECTED');
		
	WHEN NO_DATA_FOUND THEN
		DBMS_OUTPUT.PUT_LINE('DATA NOT FOUND');
	
	WHEN ZERO_DIVIDE THEN
		DBMS_OUTPUT.PUT_LINE('CANNOT DIVIDE BY ZERO');
	
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('OTHER ERRORS FOUND');
END;
/




