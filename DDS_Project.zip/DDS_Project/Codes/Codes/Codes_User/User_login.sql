SET SERVEROUTPUT ON;
SET VERIFY OFF;

BEGIN
         DBMS_OUTPUT.PUT_LINE('Enter 1(Appointment), ');
     
EXCEPTION

	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('OTHER ERRORS FOUND');
END;
/

DECLARE
	A NUMBER := &User_ID;
        userDefException EXCEPTION;
BEGIN
	
      FOR R IN (SELECT * FROM Userinfo) LOOP
		A := R.Did;		
      END LOOP;
EXCEPTION
	WHEN userDefException THEN
		DBMS_OUTPUT.PUT_LINE('Enter Either 1 or 2!!');
	
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('OTHER ERRORS FOUND');
END;
/

DECLARE
	A NUMBER := &New_old;
        userDefException EXCEPTION;
BEGIN
	
      IF A=1 THEN
         DBMS_OUTPUT.PUT_LINE('Enter all necessary patient info: ');
      ELSIF A=2 THEN
         DBMS_OUTPUT.PUT_LINE('Enter Pid: ');
      ELSE
         RAISE userDefException;
      END IF;
EXCEPTION
	WHEN userDefException THEN
		DBMS_OUTPUT.PUT_LINE('Enter Either 1 or 2!!');
	
	WHEN TOO_MANY_ROWS THEN
		DBMS_OUTPUT.PUT_LINE('MANY ROWS DETECTED');
		
	WHEN NO_DATA_FOUND THEN
		DBMS_OUTPUT.PUT_LINE('DATA NOT FOUND');
	
	WHEN ZERO_DIVIDE THEN
		DBMS_OUTPUT.PUT_LINE('CANNOT DIVIDE BY ZERO');
	
	WHEN OTHERS THEN
		DBMS_OUTPUT.PUT_LINE('OTHER ERRORS FOUND');
END;
/



