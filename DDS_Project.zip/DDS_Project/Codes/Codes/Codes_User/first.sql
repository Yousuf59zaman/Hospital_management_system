SET SERVEROUTPUT ON;
SET VERIFY OFF;

-------DECLARING A PACKAGE----------
CREATE OR REPLACE PACKAGE mypack AS
	
	PROCEDURE P1(B1 IN NUMBER);
END mypack;
/

--------IMPLEMENTING THE BODY OF A PACKAGE-------- 
CREATE OR REPLACE PACKAGE BODY mypack AS
	
	PROCEDURE P1(B1 IN NUMBER)
	IS
	
	BEGIN
		IF B1 = 1 THEN
			DBMS_OUTPUT.PUT_LINE('User Panel');
		ELSIF B1=2 THEN 
			DBMS_OUTPUT.PUT_LINE('Admin Panel');
                      END IF;
	END P1;

     
END mypack;
/


ACCEPT x NUMBER PROMPT "Enter 1(User) and 2(Admin): "
DECLARE
    User_Admin NUMBER:=&x;
BEGIN
	mypack.P1(User_Admin);
        
END;
/






