CREATE TABLE Diagnosis2 (
    diagnosis_id NUMBER PRIMARY KEY,
    prescription VARCHAR2(255),
    exam_report VARCHAR2(255),
    Aid NUMBER,
    FOREIGN KEY(Aid) REFERENCES Appointment2(Aid)
);


INSERT INTO Diagnosis2 (diagnosis_id, prescription, exam_report, Aid) VALUES (101, 'Paracetamol', 'Normal', 101);
INSERT INTO Diagnosis2 (diagnosis_id, prescription, exam_report, Aid) VALUES (102, 'Aspirin', 'Sick', 102);
INSERT INTO Diagnosis2 (diagnosis_id, prescription, exam_report, Aid) VALUES (103, 'Ibuprofen', 'Sick', 104);

commit;