SET SERVEROUTPUT ON;
CREATE OR REPLACE PACKAGE hms 
AS
   PROCEDURE proc_signup (
      p_Name   IN VARCHAR2 (50),
      p_Age    IN NUMBER,
      p_Gender IN VARCHAR2 (10),
      p_Phone  IN VARCHAR2 (20),
      p_Email  IN VARCHAR2 (50),
      p_Address IN VARCHAR2 (100),
      p_DOB    IN VARCHAR2 (50)
   );
END hms;
/

CREATE OR REPLACE PACKAGE BODY hms
AS
   PROCEDURE proc_signup (
      p_Name   IN VARCHAR2 (50),
      p_Age    IN NUMBER,
      p_Gender IN VARCHAR2 (10),
      p_Phone  IN VARCHAR2 (20),
      p_Email  IN VARCHAR2 (50),
      p_Address IN VARCHAR2 (100),
      p_DOB    IN VARCHAR2 (50)
   )
   IS
      v_ID NUMBER;
   BEGIN
      DBMS_OUTPUT.PUT_LINE ('This is proc_signup!');
      SELECT MAX (ID) + 1 INTO v_ID FROM UserInfo;
      INSERT INTO UserInfo
           VALUES (v_ID, p_Name, p_Age, p_Gender, p_Phone, p_Email, p_Address, p_DOB);
   END proc_signup;
END hms;
/

EXEC hms.proc_signup('sad',21,'ads','312213','asd','asd','231');
SET VERIFY OFF;
ACCEPT x NUMBER PROMPT "Enter 1:Admin OR 2:User"
ACCEPT y NUMBER PROMPT "Enter 1:Signup OR 2:Login"
ACCEPT name VARCHAR2(100) PROMPT "Enter name:  "
ACCEPT age NUMBER PROMPT "Enter age: "
ACCEPT gender VARCHAR2(100) PROMPT "Enter gender: "
ACCEPT phone VARCHAR2(100) PROMPT "Enter phone: "
ACCEPT email VARCHAR2(100) PROMPT "Enter email: "
ACCEPT address VARCHAR2(100) PROMPT "Enter address: "
ACCEPT dob VARCHAR2(100) PROMPT "Enter dob: "
DECLARE
   Admin_User NUMBER:=&x;
   Sign_Login NUMBER;
   userException EXCEPTION;
   Name VARCHAR2(50):='&name';
   Age NUMBER:=&age;
   Gender VARCHAR2(10):='&gender';
   Phone VARCHAR2(20):='&phone';
   Email VARCHAR2(20):='&email';
   Address VARCHAR2(100):='&address';
   DOB VARCHAR2(50):='&dob';
BEGIN
   IF Admin_User=1 THEN
      DBMS_OUTPUT.PUT_LINE('This is Admin Signin Window');
   ELSIF Admin_User=2 THEN
      DBMS_OUTPUT.PUT_LINE('This is Registration Window');
      Sign_Login :=&y;
      IF Sign_Login=1 THEN
	     
	  ELSIF Sign_Login=2 THEN
	     DBMS_OUTPUT.PUT_LINE('yes');
	  END IF;
   ELSE
       RAISE userException;
   END if;
   
   EXCEPTION
      WHEN userException THEN
	     DBMS_OUTPUT.PUT_LINE('Enter either 1 or 2 !!');
		 Admin_User:=&x;
	  WHEN TOO_MANY_ROWS THEN
	      DBMS_OUTPUT.PUT_LINE('MANY ROWS DETECTED');
      WHEN NO_DATA_FOUND THEN
	      DBMS_OUTPUT.PUT_LINE('DATA NOT FOUND');
      WHEN ZERO_DIVIDE THEN
          DBMS_OUTPUT.PUT_LINE('Cannot Divide By Zero');
	  WHEN OTHERS THEN
          DBMS_OUTPUT.PUT_LINE('OTHER ERRORS FOUND');
END;
/