SET SERVEROUTPUT ON;
SET VERIFY OFF;
DECLARE
  vID INT:=0;
  Admin_User NUMBER;
  Sign_Login NUMBER;
  User_Input_Error EXCEPTION;
  Name VARCHAR2(100);
  Age NUMBER;
  Gender VARCHAR2(100);
  Phone VARCHAR2(100);
  Email VARCHAR2(100);
  Address VARCHAR2(100);
  DOB VARCHAR2(100);
BEGIN
  Admin_User := &Admin_User;
  IF Admin_User = 1 THEN
    DBMS_OUTPUT.PUT_LINE('Admin');
  ELSIF Admin_User = 2 THEN
    DBMS_OUTPUT.PUT_LINE('User');
    Sign_Login := &Sign_Login;
    IF Sign_Login = 2 THEN
      DBMS_OUTPUT.PUT_LINE('Login Please!' || Sign_Login);
    ELSIF Sign_Login = 1 THEN
      DBMS_OUTPUT.PUT_LINE('Signup Please! ' || Sign_Login);
      Name := '&name';
      Age := &age;
      Gender := '&gender';
      Phone := '&phone';
      Email := '&email';
      Address := '&address';
      DOB := '&dob';
      DBMS_OUTPUT.PUT_LINE(Name||' '||Age||' '||Gender||' '||Phone||' '||Email||' '||Address||' '||DOB );
      FOR R IN (SELECT ID INTO vID FROM Userinfo)  
      LOOP
        vID := R.ID + 1;
      END LOOP; 
      INSERT INTO UserInfo (ID, Name, Age, Gender, Phone, Email, Address, DOB)
      VALUES (vID, Name, Age, Gender, Phone, Email, Address, DOB);
	  DBMS_OUTPUT.PUT_LINE('     ');
      DBMS_OUTPUT.PUT_LINE('     '||vID);
    ELSE
      RAISE User_Input_Error;
    END IF;
  ELSE
    RAISE User_Input_Error;
  END IF;
EXCEPTION
  WHEN User_Input_Error THEN
    DBMS_OUTPUT.PUT_LINE('PLEASE ENTER 1 OR 2 !');
END;
/



