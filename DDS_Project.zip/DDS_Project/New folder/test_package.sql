SET SERVEROUTPUT ON;
SET VERIFY OFF;

CREATE OR REPLACE PROCEDURE proc_signup (
      Name   IN VARCHAR2 (100),
      Age    IN NUMBER,
      Gender IN VARCHAR2 (100),
      Phone  IN VARCHAR2 (100),
      Email  IN VARCHAR2 (100),
      Address IN VARCHAR2 (100),
      DOB    IN VARCHAR2 (100)
   )
IS
      vID NUMBER:=0;
BEGIN
      DBMS_OUTPUT.PUT_LINE ('This is proc_signup!');
      FOR R IN (SELECT ID FROM Userinfo)  
      LOOP
        vID := R.ID + 1;
      END LOOP; 
      INSERT INTO UserInfo (ID, Name, Age, Gender, Phone, Email, Address, DOB)
      VALUES (vID, Name, Age, Gender, Phone, Email, Address, DOB);
	  DBMS_OUTPUT.PUT_LINE('     ');
      DBMS_OUTPUT.PUT_LINE('     '||vID);
END proc_signup;
/
   

DECLARE
  vID INT := 0;  
BEGIN
  
      proc_signup('hemel',21,'e','e','e','e','e');
      /*INSERT INTO UserInfo (ID, Name, Age, Gender, Phone, Email, Address, DOB)
      VALUES (vID, Name, Age, Gender, Phone, Email, Address, DOB);
	  DBMS_OUTPUT.PUT_LINE('     ');
      DBMS_OUTPUT.PUT_LINE('     '||vID);*/
    
END;
/