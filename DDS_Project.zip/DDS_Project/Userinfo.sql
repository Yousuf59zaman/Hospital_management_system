CREATE TABLE UserInfo (
  ID INT PRIMARY KEY,
  Name VARCHAR2(50) NOT NULL,
  Age NUMBER NOT NULL,
  Gender VARCHAR2(10) NOT NULL,
  Phone VARCHAR2(20) NOT NULL,
  Email VARCHAR2(50) NOT NULL,
  Address VARCHAR2(100) NOT NULL,
  DOB VARCHAR2(50) NOT NULL
);

INSERT INTO UserInfo(ID, Name, Age, Gender, Phone, Email, Address, DOB)
VALUES(1, 'Karim', 35, 'Male', '1234567890', 'johndoe@email.com', '1 Main St', '1986-01-01');
  INSERT INTO UserInfo(ID, Name, Age, Gender, Phone, Email, Address, DOB)
VALUES(2, 'Sajib', 32, 'Female', '0987654321', 'janedoe@email.com', '2 Main St', '1988-02-02');
  INSERT INTO UserInfo(ID, Name, Age, Gender, Phone, Email, Address, DOB)
VALUES(3, 'Russel', 40, 'Male', '1231231234', 'bobsmith@email.com', '3 Main St', '1983-03-03');
  INSERT INTO UserInfo(ID, Name, Age, Gender, Phone, Email, Address, DOB)
VALUES(4, 'Emily', 29, 'Female', '4564564567', 'emilyjones@email.com', '4 Main St', '1992-04-04');
  INSERT INTO UserInfo(ID, Name, Age, Gender, Phone, Email, Address, DOB)
VALUES(5, 'James Brown', 45, 'Male', '7897897897', 'jamesbrown@email.com', '5 Main St', '1978-05-05');
