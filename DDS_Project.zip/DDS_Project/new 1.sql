SET SERVEROUTPUT ON;
SET VERIFY OFF;
DECLARE
  vID INT := 0;
  Admin_User NUMBER;
  Sign_Login NUMBER;
  User_Input_Error EXCEPTION;
  
BEGIN
  
      FOR R IN (SELECT ID INTO vID FROM Userinfo)  
      LOOP
        vID := R.ID + 1;
      END LOOP; 
      /*INSERT INTO UserInfo (ID, Name, Age, Gender, Phone, Email, Address, DOB)
      VALUES (vID, Name, Age, Gender, Phone, Email, Address, DOB);*/
	  DBMS_OUTPUT.PUT_LINE('     ');
      DBMS_OUTPUT.PUT_LINE('     '||vID);
    
END;
/

